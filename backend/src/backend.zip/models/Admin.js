const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Admin = sequelize.define("administrator", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  tableName: "administrator",
  timestamps: false
});

module.exports = Admin;
