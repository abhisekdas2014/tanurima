const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Order = sequelize.define(
  "Order",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    customerId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    billNo: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    billDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    billImage: DataTypes.STRING,
    comments: DataTypes.TEXT
  },
  {
    tableName: "orders",
    timestamps: true
  }
);

module.exports = Order;
