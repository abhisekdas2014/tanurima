const sequelize = require("../config/database");
const Customer = require("./Customer");
const Order = require("./Order");
const OrderItem = require("./OrderItem");
const Item = require("./Item");
const Stock = require("./Stock");

/* ======================
   RELATIONS
====================== */

// Customer → Orders
Customer.hasMany(Order, { foreignKey: "customerId" });
Order.belongsTo(Customer, { foreignKey: "customerId", as: "customer" });

// Order → OrderItems
Order.hasMany(OrderItem, { foreignKey: "orderId" });
OrderItem.belongsTo(Order, { foreignKey: "orderId" });

// Item → OrderItems
Item.hasMany(OrderItem, { foreignKey: "itemId" });
OrderItem.belongsTo(Item, { foreignKey: "itemId" });

// Item → Stock
Item.hasMany(Stock, { foreignKey: "itemId" });
Stock.belongsTo(Item, { foreignKey: "itemId" });

module.exports = {
  sequelize,
  Customer,
  Order,
  OrderItem,
  Item,
  Stock
};
