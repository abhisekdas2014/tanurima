const { Order, OrderItem } = require("../models");

exports.create = async (req, res) => {
  console.log("🔥 CREATE START");
  console.log("BODY:", req.body);

  try {
    const customerId = Number(req.body.customerId);
    if (!customerId) {
      return res.status(400).json({ message: "Customer is required" });
    }

    const order = await Order.create({
      customerId,
      billNo: req.body.billNo,
      billDate: req.body.billDate,
      comments: req.body.comments || null,
      billImage: req.file ? req.file.filename : null
    });

    console.log("✅ ORDER ID:", order.id); // 🔥 WILL NOT BE UNDEFINED ANYMORE

    const items = JSON.parse(req.body.items || "[]");

    for (const it of items) {
      await OrderItem.create({
        orderId: order.id,
        itemId: Number(it.itemId),
        buyingPrice: it.buyingPrice,
        sellingPrice: it.sellingPrice,
        qty: Number(it.qty)
      });
    }

    res.json({
      message: "Order created successfully",
      orderId: order.id
    });

  } catch (err) {
    console.error("❌ ORDER ERROR:", err);
    res.status(500).json({ message: err.message });
  }
};
