const router = require("express").Router();
const auth = require("../middleware/auth.middleware");
const upload = require("../middleware/upload");
const controller = require("../controllers/order.controller");

router.get("/", auth, controller.getAll);
router.post("/", auth, upload.single("billImage"), controller.create);

module.exports = router;
